
AI Portfolio — Akhilesh
Files:
- index.html (Home with big AI robot + intro audio)
- projects.html, skills.html, experience.html, contact.html, chatbot.html
- css/style.css, js/main.js
- assets/robot_big.png, assets/intro.wav, assets/mini.wav
- cv.pdf (downloadable CV)
- Project_Report.pdf (PDF report for submission)
Usage: unzip and open index.html in a browser. The site uses local WAV audio for demo; browsers may block autoplay — click 'Play Intro' to hear it.
