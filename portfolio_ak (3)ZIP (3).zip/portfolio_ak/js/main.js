document.addEventListener("DOMContentLoaded", () => {
  const audio = document.getElementById("introAudio");

  // Try to unmute and play after load
  setTimeout(() => {
    audio.muted = false;
    audio.volume = 1.0;
    audio.play().catch(err => {
      console.warn("Autoplay blocked:", err);
    });
  }, 1000);
});




